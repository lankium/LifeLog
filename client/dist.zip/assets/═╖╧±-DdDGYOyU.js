const s="/assets/%E5%A4%B4%E5%83%8F-mu5Sed2p.png";export{s as _};
